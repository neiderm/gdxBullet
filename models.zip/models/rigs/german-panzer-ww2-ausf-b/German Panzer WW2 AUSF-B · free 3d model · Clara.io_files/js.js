
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "version":"23",
  
  "macros":[{
      "function":"__e"
    },{
      "function":"__dee"
    },{
      "vtp_experimentKey":"GTM-PQN88B9_OPT-MK4J2",
      "function":"__c",
      "vtp_value":true
    },{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"value"
    },{
      "vtp_experimentKey":"GTM-PQN88B9_OPT-MK4J2",
      "function":"__c",
      "vtp_value":true
    },{
      "function":"__gthc",
      "vtp_trackingId":"UA-38840155-1"
    },{
      "function":"__c",
      "vtp_value":false
    },{
      "function":"__gaoo_c",
      "vtp_trackingId":"UA-38840155-1"
    },{
      "function":"__ctto",
      "vtp_isDynamic":false
    },{
      "function":"__sel",
      "vtp_selector":":root"
    },{
      "function":"__c",
      "vtp_value":""
    },{
      "function":"__uv"
    },{
      "vtp_experimentKey":"GTM-PQN88B9_OPT-NWM8F",
      "function":"__c",
      "vtp_value":true
    },{
      "vtp_experimentKey":"GTM-PQN88B9_OPT-NWM8F",
      "function":"__c",
      "vtp_value":true
    },{
      "vtp_experimentKey":"GTM-PQN88B9_OPT-NWM8F",
      "vtp_sectionIndex":0,
      "function":"__c",
      "vtp_value":3
    },{
      "vtp_experimentKey":"GTM-PQN88B9_OPT-MK4J2",
      "vtp_sectionIndex":0,
      "function":"__c",
      "vtp_value":6
    },{
      "function":"__c",
      "vtp_value":["map","",18277,"Q8bWbsMyQse4a-PdeIaZjw",18318,"8SJx9y9eQIuo5htxak7rsQ",18360]
    }],
  "tags":[{
      "function":"__asprv",
      "vtp_globalName":"google_optimize",
      "tag_id":10
    },{
      "function":"__ua",
      "live_only":true,
      "setup_tags":["list",["tag",11,1]],
      "once_per_load":true,
      "vtp_trackingId":"UA-38840155-1",
      "vtp_setTrackerName":true,
      "vtp_trackerName":["macro",11],
      "vtp_trackType":"TRACK_DATA",
      "vtp_fieldsToSet":["list",["map","fieldName","cookieDomain","value","auto"]],
      "vtp_hitLevelFieldsToSet":["map","title","","anonymizeIp","1","nonInteraction",true,"adSenseId",["macro",12],"language",["macro",12],"encoding",["macro",12],"screenColors",["macro",12],"screenResolution",["macro",12],"viewportSize",["macro",12],"flashVersion",["macro",12],"referrer",["macro",12],"location",["macro",12]],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsData":true,
      "tag_id":26
    },{
      "function":"__ua",
      "live_only":true,
      "setup_tags":["list",["tag",10,1]],
      "once_per_load":true,
      "vtp_trackingId":"UA-38840155-1",
      "vtp_setTrackerName":true,
      "vtp_trackerName":["macro",11],
      "vtp_trackType":"TRACK_DATA",
      "vtp_fieldsToSet":["list",["map","fieldName","cookieDomain","value","auto"]],
      "vtp_hitLevelFieldsToSet":["map","title","","anonymizeIp","1","nonInteraction",true,"adSenseId",["macro",12],"language",["macro",12],"encoding",["macro",12],"screenColors",["macro",12],"screenResolution",["macro",12],"viewportSize",["macro",12],"flashVersion",["macro",12],"referrer",["macro",12],"location",["macro",12]],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsData":true,
      "tag_id":49
    },{
      "function":"__dr",
      "once_per_event":true,
      "vtp_measurementId":"8SJx9y9eQIuo5htxak7rsQ",
      "vtp_experimentCombination":["template",["macro",15]],
      "vtp_activate":false,
      "vtp_isEmpty":false,
      "vtp_treatmentId":"Experiment_GTM-PQN88B9_OPT-NWM8F:0",
      "vtp_contextIndex":0,
      "tag_id":66
    },{
      "function":"__dr",
      "once_per_event":true,
      "vtp_measurementId":"Q8bWbsMyQse4a-PdeIaZjw",
      "vtp_experimentCombination":["template",["macro",16]],
      "vtp_activate":false,
      "vtp_isEmpty":false,
      "vtp_treatmentId":"Experiment_GTM-PQN88B9_OPT-MK4J2:0",
      "vtp_contextIndex":0,
      "tag_id":67
    },{
      "function":"__noop",
      "setup_tags":["list",["tag",14,1]],
      "teardown_tags":["list",["tag",9,2]],
      "vtp_measurementId":"Q8bWbsMyQse4a-PdeIaZjw",
      "vtp_contextIndex":0,
      "vtp_sectionIndex":0,
      "vtp_variant":6,
      "tag_id":74
    },{
      "function":"__noop",
      "setup_tags":["list",["tag",8,1]],
      "teardown_tags":["list",["tag",7,2]],
      "vtp_measurementId":"8SJx9y9eQIuo5htxak7rsQ",
      "vtp_contextIndex":0,
      "vtp_sectionIndex":0,
      "vtp_variant":3,
      "tag_id":78
    },{
      "function":"__esc",
      "vtp_selector":"body",
      "vtp_identifier":"body",
      "vtp_script":"const adLink = \"https:\/\/www.threekit.com\/free-trial-request\"\nconst adImage = \"https:\/\/drive.google.com\/uc?id=11llkLY5nMNDhiETGK_fyQe6ECMvjqIST\"\n\nconst anchorElem = document.getElementsByName('ad-link')[0];\nconst imageElem = document.getElementsByName('ad-image')[0];\n\nif (anchorElem \u0026\u0026 imageElem) {\n   anchorElem.href = adLink;\n   imageElem.src  = adImage;\n}\n\nlet sent = false;\nanchorElem.addEventListener('click', (event) =\u003E {\n  if(!sent) {\n    event.preventDefault();\n    sent = true;\n    setTimeout(() =\u003E anchorElem.click(), 1000);\n    ga('send', 'event', 'ThreekitAd', 'Click', {\n      hitCallback: () =\u003E anchorElem.click()\n    });\n  }\n});",
      "vtp_requiresContent":true,
      "tag_id":59
    },{
      "function":"__dr",
      "setup_tags":["list",["tag",10,1]],
      "once_per_event":true,
      "vtp_measurementId":"8SJx9y9eQIuo5htxak7rsQ",
      "vtp_experimentCombination":["template",["macro",15]],
      "vtp_activate":true,
      "vtp_isEmpty":false,
      "vtp_treatmentId":"Experiment_GTM-PQN88B9_OPT-NWM8F:0",
      "vtp_contextIndex":0,
      "tag_id":53
    },{
      "function":"__esc",
      "vtp_selector":"body",
      "vtp_identifier":"body",
      "vtp_script":"const adLink = \"https:\/\/www.threekit.com\"\nconst adImage = \"https:\/\/drive.google.com\/uc?id=17h1Pnk0fOoYe_f5hoEQz6KISifgEjd9L\"\n\nconst anchorElem = document.getElementsByName('ad-link')[0];\nconst imageElem = document.getElementsByName('ad-image')[0];\n\nif (anchorElem \u0026\u0026 imageElem) {\n   anchorElem.href = adLink;\n   imageElem.src  = adImage;\n}\n\nlet sent = false;\nanchorElem.addEventListener('click', (event) =\u003E {\n  if(!sent) {\n    event.preventDefault();\n    sent = true;\n    setTimeout(() =\u003E anchorElem.click(), 1000);\n    ga('send', 'event', 'ThreekitAd', 'Click', {\n      hitCallback: () =\u003E anchorElem.click()\n    });\n  }\n});",
      "vtp_requiresContent":true,
      "tag_id":42
    },{
      "function":"__uae",
      "live_only":true,
      "setup_tags":["list",["tag",12,1]],
      "once_per_load":true,
      "vtp_measurementId":"8SJx9y9eQIuo5htxak7rsQ",
      "vtp_trackingId":"UA-38840155-1",
      "vtp_experimentCombination":["template",["macro",15]],
      "tag_id":48
    },{
      "function":"__uae",
      "live_only":true,
      "setup_tags":["list",["tag",13,1]],
      "once_per_load":true,
      "vtp_measurementId":"Q8bWbsMyQse4a-PdeIaZjw",
      "vtp_trackingId":"UA-38840155-1",
      "vtp_experimentCombination":["template",["macro",16]],
      "tag_id":17
    },{
      "function":"__exsu",
      "once_per_event":true,
      "vtp_measurementId":"8SJx9y9eQIuo5htxak7rsQ",
      "vtp_newState":["template",["macro",15]],
      "vtp_expirationDay":18447,
      "vtp_expirationDates":["macro",17],
      "tag_id":46
    },{
      "function":"__exsu",
      "once_per_event":true,
      "vtp_measurementId":"Q8bWbsMyQse4a-PdeIaZjw",
      "vtp_newState":["template",["macro",16]],
      "vtp_expirationDay":18447,
      "vtp_expirationDates":["macro",17],
      "tag_id":14
    },{
      "function":"__dr",
      "setup_tags":["list",["tag",11,1]],
      "once_per_event":true,
      "vtp_measurementId":"Q8bWbsMyQse4a-PdeIaZjw",
      "vtp_experimentCombination":["template",["macro",16]],
      "vtp_activate":true,
      "vtp_isEmpty":false,
      "vtp_treatmentId":"Experiment_GTM-PQN88B9_OPT-MK4J2:0",
      "vtp_contextIndex":0,
      "tag_id":30
    }],
  "predicates":[{
      "function":"_eq",
      "arg0":["macro",0],
      "arg1":["macro",1]
    },{
      "function":"_eq",
      "arg0":["macro",0],
      "arg1":"optimize.callback"
    },{
      "function":"_cn",
      "arg0":["macro",3],
      "arg1":["list","https:\/\/blue.clara.io\/view","https:\/\/blue.clara.io\/library"],
      "any_of":true
    },{
      "function":"_eq",
      "arg0":["macro",0],
      "arg1":"optimize.activate"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"library"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":0
    },{
      "function":"_eq",
      "arg0":true,
      "arg1":["list",["macro",7],["macro",8]],
      "any_of":true
    },{
      "function":"_eq",
      "arg0":["macro",9],
      "arg1":true
    },{
      "function":"_eq",
      "arg0":["macro",10],
      "arg1":"null"
    },{
      "function":"_cn",
      "arg0":["macro",3],
      "arg1":["list","https:\/\/clara.io\/view","https:\/\/clara.io\/library"],
      "any_of":true
    }],
  "rules":[
    [["if",0],["add",0]],
    [["if",1],["add",0]],
    [["if",2,3,4],["unless",5],["add",1]],
    [["if",3,4,9],["unless",5],["add",2]],
    [["if",3],["unless",9],["add",3]],
    [["if",3],["unless",4],["add",3,4]],
    [["if",3],["unless",2],["add",4]],
    [["if",2,3,4],["add",5]],
    [["if",3,4,9],["add",6]],
    [["if",6],["block",1,2,3,4,5,6]],
    [["if",7],["block",1,2,3,4,5,6]],
    [["if",8],["block",1,2,3,4,5,6]]]
},
"runtime":[]



};
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var aa,ba="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},ca;if("function"==typeof Object.setPrototypeOf)ca=Object.setPrototypeOf;else{var da;a:{var ea={Oe:!0},fa={};try{fa.__proto__=ea;da=fa.Oe;break a}catch(a){}da=!1}ca=da?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var ia=ca,ka=this||self,la=/^[\w+/_-]+[=]{0,2}$/,ma=null;var pa=function(){},qa=function(a){return"function"==typeof a},f=function(a){return"string"==typeof a},ra=function(a){return"number"==typeof a&&!isNaN(a)},ua=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},r=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},va=function(a,b){if(a&&ua(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},wa=function(a,b){if(!ra(a)||
!ra(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},ya=function(a,b){for(var c=new xa,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},za=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Aa=function(a){return Math.round(Number(a))||0},Ca=function(a){return"false"==String(a).toLowerCase()?!1:!!a},Da=function(a){var b=[];if(ua(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Ea=function(a){return a?
a.replace(/^\s+|\s+$/g,""):""},Fa=function(){return(new Date).getTime()},xa=function(){this.prefix="gtm.";this.values={}};xa.prototype.set=function(a,b){this.values[this.prefix+a]=b};xa.prototype.get=function(a){return this.values[this.prefix+a]};
var Ga=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Ha=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},Ia=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ja=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},Ka=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},La=function(a,b){for(var c={},d=c,e=a.split("."),g=0;g<e.length-1;g++)d=d[e[g]]={};d[e[e.length-1]]=b;return c};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Ma=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Na=function(a){if(null==a)return String(a);var b=Ma.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Oa=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Pa=function(a){if(!a||"object"!=Na(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Oa(a,"constructor")&&!Oa(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Oa(a,b)},C=function(a,b){var c=b||("array"==Na(a)?[]:{}),d;for(d in a)if(Oa(a,d)){var e=a[d];"array"==Na(e)?("array"!=Na(c[d])&&(c[d]=[]),c[d]=C(e,c[d])):Pa(e)?(Pa(c[d])||(c[d]={}),c[d]=C(e,c[d])):c[d]=e}return c};var ob;
var pb=[],qb=[],rb=[],sb=[],tb=[],vb={},wb,xb,yb,zb=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},Ab=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=vb[c],e={},g;for(g in a)a.hasOwnProperty(g)&&0===g.indexOf("vtp_")&&(e[void 0!==d?g:g.substr(4)]=a[g]);return void 0!==d?d(e):ob(c,e,b)},Cb=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=Bb(a[e],b,c));
return d},Db=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=vb[b];return c?c.priorityOverride||0:0},Bb=function(a,b,c){if(ua(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(Bb(a[e],b,c));return d;case "macro":var g=a[1];if(c[g])return;var h=pb[g];if(!h||b.Dc(h))return;c[g]=!0;try{var k=Cb(h,b,c);k.vtp_gtmEventId=b.id;d=Ab(k,b);yb&&(d=yb.qf(d,k))}catch(y){b.de&&b.de(y,Number(g)),d=!1}c[g]=
!1;return d;case "map":d={};for(var l=1;l<a.length;l+=2)d[Bb(a[l],b,c)]=Bb(a[l+1],b,c);return d;case "template":d=[];for(var m=!1,n=1;n<a.length;n++){var q=Bb(a[n],b,c);xb&&(m=m||q===xb.pb);d.push(q)}return xb&&m?xb.tf(d):d.join("");case "escape":d=Bb(a[1],b,c);if(xb&&ua(a[1])&&"macro"===a[1][0]&&xb.ag(a))return xb.Ag(d);d=String(d);for(var u=2;u<a.length;u++)Qa[a[u]]&&(d=Qa[a[u]](d));return d;case "tag":var p=a[1];if(!sb[p])throw Error("Unable to resolve tag reference "+p+".");return d={Zd:a[2],
index:p};case "zb":var t={arg0:a[2],arg1:a[3],ignore_case:a[5]};t["function"]=a[1];var v=Fb(t,b,c),w=!!a[4];return w||2!==v?w!==(1===v):null;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},Fb=function(a,b,c){try{return wb(Cb(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Gb=function(){var a=function(b){return{toString:function(){return b}}};return{md:a("convert_case_to"),nd:a("convert_false_to"),od:a("convert_null_to"),pd:a("convert_true_to"),qd:a("convert_undefined_to"),ih:a("debug_mode_metadata"),oa:a("function"),Ee:a("instance_name"),Ge:a("live_only"),He:a("malware_disabled"),Ie:a("metadata"),oh:a("original_vendor_template_id"),Je:a("once_per_event"),Ad:a("once_per_load"),Fd:a("setup_tags"),Hd:a("tag_id"),Id:a("teardown_tags")}}();var Hb=null,Kb=function(a){function b(q){for(var u=0;u<q.length;u++)d[q[u]]=!0}var c=[],d=[];Hb=Ib(a);for(var e=0;e<qb.length;e++){var g=qb[e],h=Jb(g);if(h){for(var k=g.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(g.block||[])}else null===h&&b(g.block||[])}for(var m=[],n=0;n<sb.length;n++)c[n]&&!d[n]&&(m[n]=!0);return m},Jb=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Hb(b[c]);if(0===d)return!1;if(2===d)return null}for(var e=a.unless||[],g=0;g<e.length;g++){var h=Hb(e[g]);if(2===h)return null;
if(1===h)return!1}return!0},Ib=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Fb(rb[c],a));return b[c]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */
var D=window,F=document,Zb=navigator,$b=F.currentScript&&F.currentScript.src,ac=function(a,b){var c=D[a];D[a]=void 0===c?b:c;return D[a]},bc=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},cc=function(a,b,c){var d=F.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;bc(d,b);c&&(d.onerror=c);var e;if(null===ma)b:{var g=ka.document,h=g.querySelector&&g.querySelector("script[nonce]");
if(h){var k=h.nonce||h.getAttribute("nonce");if(k&&la.test(k)){ma=k;break b}}ma=""}e=ma;e&&d.setAttribute("nonce",e);var l=F.getElementsByTagName("script")[0]||F.body||F.head;l.parentNode.insertBefore(d,l);return d},dc=function(){if($b){var a=$b.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},ec=function(a,b){var c=F.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=F.body&&F.body.lastChild||
F.body||F.head;d.parentNode.insertBefore(c,d);bc(c,b);void 0!==a&&(c.src=a);return c},fc=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},gc=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},hc=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},G=function(a){D.setTimeout(a,0)},ic=function(a,b){return a&&
b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},jc=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},kc=function(a){var b=F.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},lc=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var g=a,h=0;g&&h<=c;h++){if(d[String(g.tagName).toLowerCase()])return g;
g=g.parentElement}return null},mc=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var oc=function(a){return nc?F.querySelectorAll(a):null},pc=function(a,b){if(!nc)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!F.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},qc=!1;if(F.querySelectorAll)try{var rc=F.querySelectorAll(":root");rc&&1==rc.length&&rc[0]==F.documentElement&&(qc=!0)}catch(a){}var nc=qc;var H={na:"_ee",fc:"event_callback",Pa:"event_timeout",D:"gtag.config",T:"allow_ad_personalization_signals",gc:"restricted_data_processing",W:"cookie_expires",Oa:"cookie_update",xa:"session_duration",ba:"user_properties"};var Ic=/[A-Z]+/,Jc=/\s/,Kc=function(a){if(f(a)&&(a=Ea(a),!Jc.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Ic.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],m:d}}}}},Mc=function(a){for(var b={},c=0;c<a.length;++c){var d=Kc(a[c]);d&&(b[d.id]=d)}Lc(b);var e=[];za(b,function(g,h){e.push(h)});return e};
function Lc(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.m[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var Nc={},Oc=null,Pc=Math.random();Nc.s="GTM-PQN88B9";Nc.tb="181";var Qc={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0,__paused:!0,__tg:!0},Rc="www.google-analytics.com/gtm.js";var Sc=Rc,Tc=null,Uc=null,Vc=null,Wc="//www.googletagmanager.com/a?id="+Nc.s+"&cv=23",Xc={},Yc={},Zc=function(){var a=Oc.sequence||0;Oc.sequence=a+1;return a};var $c={},I=function(a,b){$c[a]=$c[a]||[];$c[a][b]=!0},ad=function(a){for(var b=[],c=$c[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};
var cd=function(){return"&tc="+sb.filter(function(a){return a}).length},fd=function(){dd||(dd=D.setTimeout(ed,500))},ed=function(){dd&&(D.clearTimeout(dd),dd=void 0);void 0===gd||hd[gd]&&!id&&!jd||(kd[gd]||ld.cg()||0>=md--?(I("GTM",1),kd[gd]=!0):(ld.Jg(),fc(nd()),hd[gd]=!0,od=pd=jd=id=""))},nd=function(){var a=gd;if(void 0===a)return"";var b=ad("GTM"),c=ad("TAGGING");return[qd,hd[a]?"":"&es=1",rd[a],b?"&u="+b:"",c?"&ut="+c:"",cd(),id,jd,pd,od,"&z=0"].join("")},sd=function(){return[Wc,"&v=3&t=t","&pid="+
wa(),"&rv="+Nc.tb].join("")},td="0.005000">Math.random(),qd=sd(),ud=function(){qd=sd()},hd={},id="",jd="",od="",pd="",gd=void 0,rd={},kd={},dd=void 0,ld=function(a,b){var c=0,d=0;return{cg:function(){if(c<a)return!1;Fa()-d>=b&&(c=0);return c>=a},Jg:function(){Fa()-d>=b&&(c=0);c++;d=Fa()}}}(2,1E3),md=1E3,vd=function(a,b){if(td&&!kd[a]&&gd!==a){ed();gd=a;od=id="";var c;c=0===b.indexOf("gtm.")?encodeURIComponent(b):"*";rd[a]="&e="+c+"&eid="+a;fd()}},wd=function(a,b,c){if(td&&!kd[a]&&
b){a!==gd&&(ed(),gd=a);var d,e=String(b[Gb.oa]||"").replace(/_/g,"");0===e.indexOf("cvt")&&(e="cvt");d=e;var g=c+d;id=id?id+"."+g:"&tr="+g;fd();2022<=nd().length&&ed()}},xd=function(a,b,c){if(td&&!kd[a]){a!==gd&&(ed(),gd=a);var d=c+b;jd=jd?jd+
"."+d:"&epr="+d;fd();2022<=nd().length&&ed()}};var yd={},zd=new xa,Ad={},Bd={},Ed={name:"dataLayer",set:function(a,b){C(La(a,b),Ad);Cd()},get:function(a){return Dd(a,2)},reset:function(){zd=new xa;Ad={};Cd()}},Dd=function(a,b){if(2!=b){var c=zd.get(a);if(td){var d=Fd(a);c!==d&&I("GTM",5)}return c}return Fd(a)},Fd=function(a,b,c){var d=a.split("."),e=!1,g=void 0;return e?g:Hd(d)},Hd=function(a){for(var b=Ad,c=0;c<a.length;c++){if(null===b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var Jd=function(a,b){Bd.hasOwnProperty(a)||(zd.set(a,b),C(La(a,b),Ad),Cd())},Cd=function(a){za(Bd,function(b,c){zd.set(b,c);C(La(b,void 0),Ad);C(La(b,c),Ad);a&&delete Bd[b]})},Kd=function(a,b,c){yd[a]=yd[a]||{};var d=1!==c?Fd(b):zd.get(b);"array"===Na(d)||"object"===Na(d)?yd[a][b]=C(d):yd[a][b]=d},Ld=function(a,b){if(yd[a])return yd[a][b]};var Md=function(){var a=!1;return a};var Q=function(a,b,c,d){return(2===Nd()||d||"http:"!=D.location.protocol?a:b)+c},Nd=function(){var a=dc(),b;if(1===a)a:{var c=Sc;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,g=1,h=F.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===g&&0===l.indexOf(d)&&(g=2)}}b=g}else b=a;return b};var be=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),ce={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},de={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},ee="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var ge=function(a){Yc.pntr=Yc.pntr||["nonGoogleScripts"];Yc.snppx=Yc.snppx||["nonGoogleScripts"];Yc.qpx=Yc.qpx||["nonGooglePixels"];var b=Dd("gtm.whitelist");b&&I("GTM",9);
var c=b&&Ka(Da(b),ce),d=Dd("gtm.blacklist");d||(d=Dd("tagTypeBlacklist"))&&I("GTM",3);d?I("GTM",8):d=[];fe()&&(d=Da(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=r(Da(d),"google")&&I("GTM",2);var e=d&&Ka(Da(d),de),g={};return function(h){var k=h&&h[Gb.oa];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==g[k])return g[k];
var l=Yc[k]||[],m=a(k,l);if(b){var n;if(n=m)a:{if(0>r(c,k))if(l&&0<l.length)for(var q=0;q<l.length;q++){if(0>r(c,l[q])){I("GTM",11);n=!1;break a}}else{n=!1;break a}n=!0}m=n}var u=!1;if(d){var p=0<=r(e,k);if(p)u=p;else{var t=ya(e,l||[]);t&&I("GTM",10);u=t}}var v=!m||u;v||!(0<=r(l,"sandboxedScripts"))||c&&-1!==r(c,"sandboxedScripts")||(v=ya(e,ee));return g[k]=v}},fe=function(){return be.test(D.location&&D.location.hostname)};var he={qf:function(a,b){b[Gb.md]&&"string"===typeof a&&(a=1==b[Gb.md]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Gb.od)&&null===a&&(a=b[Gb.od]);b.hasOwnProperty(Gb.qd)&&void 0===a&&(a=b[Gb.qd]);b.hasOwnProperty(Gb.pd)&&!0===a&&(a=b[Gb.pd]);b.hasOwnProperty(Gb.nd)&&!1===a&&(a=b[Gb.nd]);return a}};var ie={active:!0,isWhitelisted:function(){return!0}},je=function(a){var b=Oc.zones;!b&&a&&(b=Oc.zones=a());return b};var ke=function(){};var le=!1,me=0,ne=[];function oe(a){if(!le){var b=F.createEventObject,c="complete"==F.readyState,d="interactive"==F.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){le=!0;for(var e=0;e<ne.length;e++)G(ne[e])}ne.push=function(){for(var g=0;g<arguments.length;g++)G(arguments[g]);return 0}}}function pe(){if(!le&&140>me){me++;try{F.documentElement.doScroll("left"),oe()}catch(a){D.setTimeout(pe,50)}}}var qe=function(a){le?a():ne.push(a)};var re={},se={},te=function(a,b,c,d){if(!se[a]||Qc[b]||"__zone"===b)return-1;var e={};Pa(d)&&(e=C(d,e));e.id=c;e.status="timeout";return se[a].tags.push(e)-1},ue=function(a,b,c,d){if(se[a]){var e=se[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function ve(a){for(var b=re[a]||[],c=0;c<b.length;c++)b[c]();re[a]={push:function(d){d(Nc.s,se[a])}}}
var ye=function(a,b,c){se[a]={tags:[]};qa(b)&&we(a,b);c&&D.setTimeout(function(){return ve(a)},Number(c));return xe(a)},we=function(a,b){re[a]=re[a]||[];re[a].push(Ha(function(){return G(function(){b(Nc.s,se[a])})}))};function xe(a){var b=0,c=0,d=!1;return{add:function(){c++;return Ha(function(){b++;d&&b>=c&&ve(a)})},Ze:function(){d=!0;b>=c&&ve(a)}}};var ze=function(){function a(d){return!ra(d)||0>d?0:d}if(!Oc._li&&D.performance&&D.performance.timing){var b=D.performance.timing.navigationStart,c=ra(Ed.get("gtm.start"))?Ed.get("gtm.start"):0;Oc._li={cst:a(c-b),cbt:a(Uc-b)}}};var De=!1,Ee=function(){return D.GoogleAnalyticsObject&&D[D.GoogleAnalyticsObject]},Fe=!1;
var Ge=function(a){D.GoogleAnalyticsObject||(D.GoogleAnalyticsObject=a||"ga");var b=D.GoogleAnalyticsObject;if(D[b])D.hasOwnProperty(b)||I("GTM",12);else{var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(new Date);D[b]=c}ze();return D[b]},He=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=Ee();e(a+"require","linker");e(a+"linker:autoLink",b,c,d)};
var Je=function(){if(De||Fe)return;var a=D[Ie()];qa(a)&&(a("provide",Nc.s,pa),De=!0);},Ie=function(){return D.GoogleAnalyticsObject||"ga"};var Le=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var Me=/:[0-9]+$/,Ne=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var g=d[e].split("=");if(decodeURIComponent(g[0]).replace(/\+/g," ")===b){var h=g.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},Qe=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=Oe(a.protocol)||Oe(D.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:D.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||D.location.hostname).replace(Me,"").toLowerCase());var g=b,h,k=Oe(a.protocol);g&&(g=String(g).toLowerCase());switch(g){case "url_no_fragment":h=Pe(a);break;case "protocol":h=k;break;case "host":h=a.hostname.replace(Me,"").toLowerCase();if(c){var l=/^www\d*\./.exec(h);l&&l[0]&&(h=h.substr(l[0].length))}break;case "port":h=String(Number(a.port)||("http"==k?80:"https"==k?443:""));break;case "path":a.pathname||a.hostname||I("TAGGING",1);h="/"==a.pathname.substr(0,1)?a.pathname:
"/"+a.pathname;var m=h.split("/");0<=r(d||[],m[m.length-1])&&(m[m.length-1]="");h=m.join("/");break;case "query":h=a.search.replace("?","");e&&(h=Ne(h,e,void 0));break;case "extension":var n=a.pathname.split(".");h=1<n.length?n[n.length-1]:"";h=h.split("/")[0];break;case "fragment":h=a.hash.replace("#","");break;default:h=a&&a.href}return h},Oe=function(a){return a?a.replace(":","").toLowerCase():""},Pe=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");b=0>c?a.href:a.href.substr(0,c)}return b},
Re=function(a){var b=F.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||I("TAGGING",1),c="/"+c);var d=b.hostname.replace(Me,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}};function We(a,b,c,d){var e=sb[a],g=Xe(a,b,c,d);if(!g)return null;var h=Bb(e[Gb.Fd],c,[]);if(h&&h.length){var k=h[0];g=We(k.index,{B:g,w:1===k.Zd?b.terminate:g,terminate:b.terminate},c,d)}return g}
function Xe(a,b,c,d){function e(){if(g[Gb.He])k();else{var w=Cb(g,c,[]),y=te(c.id,String(g[Gb.oa]),Number(g[Gb.Hd]),w[Gb.Ie]),x=!1;w.vtp_gtmOnSuccess=function(){if(!x){x=!0;var A=Fa()-B;wd(c.id,sb[a],"5");ue(c.id,y,"success",A);h()}};w.vtp_gtmOnFailure=function(){if(!x){x=!0;var A=Fa()-B;wd(c.id,sb[a],"6");ue(c.id,y,"failure",A);k()}};w.vtp_gtmTagId=g.tag_id;
w.vtp_gtmEventId=c.id;wd(c.id,g,"1");var z=function(){var A=Fa()-B;wd(c.id,g,"7");ue(c.id,y,"exception",A);x||(x=!0,k())};var B=Fa();try{Ab(w,c)}catch(A){z(A)}}}var g=sb[a],h=b.B,k=b.w,l=b.terminate;if(c.Dc(g))return null;var m=Bb(g[Gb.Id],c,[]);if(m&&m.length){var n=m[0],q=We(n.index,{B:h,w:k,terminate:l},c,d);if(!q)return null;h=q;k=2===n.Zd?l:q}if(g[Gb.Ad]||g[Gb.Je]){var u=g[Gb.Ad]?tb:c.Sg,p=h,t=k;if(!u[a]){e=Ha(e);var v=Ye(a,u,e);h=v.B;k=v.w}return function(){u[a](p,t)}}return e}
function Ye(a,b,c){var d=[],e=[];b[a]=Ze(d,e,c);return{B:function(){b[a]=$e;for(var g=0;g<d.length;g++)d[g]()},w:function(){b[a]=af;for(var g=0;g<e.length;g++)e[g]()}}}function Ze(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function $e(a){a()}function af(a,b){b()};var df=function(a,b){for(var c=[],d=0;d<sb.length;d++)if(a.hb[d]){var e=sb[d];var g=b.add();try{var h=We(d,{B:g,w:g,terminate:g},a,d);h?c.push({qe:d,ke:Db(e),Bf:h}):(bf(d,a),g())}catch(l){g()}}b.Ze();c.sort(cf);for(var k=0;k<c.length;k++)c[k].Bf();return 0<c.length};function cf(a,b){var c,d=b.ke,e=a.ke;c=d>e?1:d<e?-1:0;var g;if(0!==c)g=c;else{var h=a.qe,k=b.qe;g=h>k?1:h<k?-1:0}return g}
function bf(a,b){if(!td)return;var c=function(d){var e=b.Dc(sb[d])?"3":"4",g=Bb(sb[d][Gb.Fd],b,[]);g&&g.length&&c(g[0].index);wd(b.id,sb[d],e);var h=Bb(sb[d][Gb.Id],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var ef=!1,ff=function(a,b,c,d,e){if("gtm.js"==b){if(ef)return!1;ef=!0}vd(a,b);var g=ye(a,d,e);Kd(a,"event",1);Kd(a,"ecommerce",1);Kd(a,"gtm");var h={id:a,name:b,Dc:ge(c),hb:[],Sg:[],de:function(){I("GTM",6)}};h.hb=Kb(h);var k=df(h,g);"gtm.js"!==b&&"gtm.sync"!==b||Je();
if(!k)return k;for(var l=0;l<h.hb.length;l++)if(h.hb[l]){var m=sb[l];if(m&&!Qc[String(m[Gb.oa])])return!0}return!1};var hf=/^https?:\/\/www\.googletagmanager\.com/;function jf(){var a;return a}function lf(a,b){}
function kf(a){0!==a.indexOf("http://")&&0!==a.indexOf("https://")&&(a="https://"+a);"/"===a[a.length-1]&&(a=a.substring(0,a.length-1));return a}function mf(){var a=!1;return a};var nf=function(){this.eventModel={};this.targetConfig={};this.containerConfig={};this.h={};this.globalConfig={};this.B=function(){};this.w=function(){}},of=function(a){var b=new nf;b.eventModel=a;return b},pf=function(a,b){a.targetConfig=b;return a},qf=function(a,b){a.containerConfig=b;return a},rf=function(a,b){a.h=b;return a},sf=function(a,b){a.globalConfig=b;return a},tf=function(a,b){a.B=b;return a},uf=function(a,b){a.w=b;return a};
nf.prototype.getWithConfig=function(a){if(void 0!==this.eventModel[a])return this.eventModel[a];if(void 0!==this.targetConfig[a])return this.targetConfig[a];if(void 0!==this.containerConfig[a])return this.containerConfig[a];if(void 0!==this.h[a])return this.h[a];if(void 0!==this.globalConfig[a])return this.globalConfig[a]};
var vf=function(a){function b(e){za(e,function(g){c[g]=null})}var c={};b(a.eventModel);b(a.targetConfig);b(a.containerConfig);b(a.globalConfig);var d=[];za(c,function(e){d.push(e)});return d};var wf={},xf=["G"];wf.se="";var yf=wf.se.split(",");function zf(){var a=Oc;return a.gcq=a.gcq||new Af}
var Bf=function(a,b,c){zf().register(a,b,c)},Cf=function(a,b,c,d){zf().push("event",[b,a],c,d)},Df=function(a,b){zf().push("config",[a],b)},Ef={},Ff=function(){this.status=1;this.containerConfig={};this.targetConfig={};this.i={};this.o=null;this.h=!1},Gf=function(a,b,c,d,e){this.type=a;this.o=b;this.M=c||"";this.h=d;this.i=e},Af=function(){this.i={};this.o={};this.h=[]},Hf=function(a,b){var c=Kc(b);return a.i[c.containerId]=a.i[c.containerId]||new Ff},If=function(a,b,c,d){if(d.M){var e=Hf(a,d.M),
g=e.o;if(g){var h=C(c),k=C(e.targetConfig[d.M]),l=C(e.containerConfig),m=C(e.i),n=C(a.o),q=Dd("gtm.uniqueEventId"),u=Kc(d.M).prefix,p=uf(tf(sf(rf(qf(pf(of(h),k),l),m),n),function(){xd(q,u,"2");}),function(){xd(q,u,"3");});try{xd(q,u,"1");3===g.length?g(b,d.o,p):4===g.length&&g(d.M,b,d.o,
p)}catch(t){xd(q,u,"4");}}}};
Af.prototype.register=function(a,b,c){if(3!==Hf(this,a).status){Hf(this,a).o=b;Hf(this,a).status=3;c&&(Hf(this,a).i=c);var d=Kc(a),e=Ef[d.containerId];if(void 0!==e){var g=Oc[d.containerId].bootstrap,h=d.prefix.toUpperCase();Oc[d.containerId]._spx&&(h=h.toLowerCase());var k=Dd("gtm.uniqueEventId"),l=h,m=Fa()-g;if(td&&!kd[k]){k!==gd&&(ed(),gd=k);var n=l+"."+Math.floor(g-e)+"."+Math.floor(m);pd=pd?pd+","+n:"&cl="+n}delete Ef[d.containerId]}this.flush()}};
Af.prototype.push=function(a,b,c,d){var e=Math.floor(Fa()/1E3);if(c){var g=Kc(c),h;if(h=g){var k;if(k=1===Hf(this,c).status)a:{var l=g.prefix;k=!0}h=k}if(h&&(Hf(this,c).status=2,this.push("require",[],g.containerId),Ef[g.containerId]=Fa(),!Md())){var m=encodeURIComponent(g.containerId),n=("http:"!=D.location.protocol?"https:":"http:")+
"//www.google-analytics.com";cc(n+"/gtag/js?id="+m+"&l=dataLayer&cx=c")}}this.h.push(new Gf(a,e,c,b,d));d||this.flush()};
Af.prototype.flush=function(a){for(var b=this;this.h.length;){var c=this.h[0];if(c.i)c.i=!1,this.h.push(c);else switch(c.type){case "require":if(3!==Hf(this,c.M).status&&!a)return;break;case "set":za(c.h[0],function(l,m){C(La(l,m),b.o)});break;case "config":var d=c.h[0],e=!!d[H.Fb];delete d[H.Fb];var g=Hf(this,c.M),h=Kc(c.M),k=h.containerId===h.id;e||(k?g.containerConfig={}:g.targetConfig[c.M]={});g.h&&e||If(this,H.D,d,c);g.h=!0;delete d[H.na];k?C(d,g.containerConfig):C(d,g.targetConfig[c.M]);break;
case "event":If(this,c.h[1],c.h[0],c)}this.h.shift()}};var Jf=function(a,b,c){for(var d=[],e=String(b||document.cookie).split(";"),g=0;g<e.length;g++){var h=e[g].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d},Mf=function(a,b,c,d){var e=Kf(a,d);if(1===e.length)return e[0].id;if(0!==e.length){e=Lf(e,function(g){return g.Hb},b);if(1===e.length)return e[0].id;e=Lf(e,function(g){return g.ib},c);return e[0]?e[0].id:void 0}};
function Nf(a,b,c){var d=document.cookie;document.cookie=a;var e=document.cookie;return d!=e||void 0!=c&&0<=Jf(b,e).indexOf(c)}
var Rf=function(a,b,c,d,e,g){d=d||"auto";var h={path:c||"/"};e&&(h.expires=e);"none"!==d&&(h.domain=d);var k;a:{var l=b,m;if(void 0==l)m=a+"=deleted; expires="+(new Date(0)).toUTCString();else{g&&(l=encodeURIComponent(l));var n=l;n&&1200<n.length&&(n=n.substring(0,1200));l=n;m=a+"="+l}var q=void 0,u=void 0,p;for(p in h)if(h.hasOwnProperty(p)){var t=h[p];if(null!=t)switch(p){case "secure":t&&(m+="; secure");break;case "domain":q=t;break;default:"path"==p&&(u=t),"expires"==p&&t instanceof Date&&(t=
t.toUTCString()),m+="; "+p+"="+t}}if("auto"===q){for(var v=Of(),w=0;w<v.length;++w){var y="none"!=v[w]?v[w]:void 0;if(!Pf(y,u)&&Nf(m+(y?"; domain="+y:""),a,l)){k=!0;break a}}k=!1}else q&&"none"!=q&&(m+="; domain="+q),k=!Pf(q,u)&&Nf(m,a,l)}return k};function Lf(a,b,c){for(var d=[],e=[],g,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===g||l<g?(e=[k],g=l):l===g&&e.push(k)}return 0<d.length?d:e}
function Kf(a,b){for(var c=[],d=Jf(a),e=0;e<d.length;e++){var g=d[e].split("."),h=g.shift();if(!b||-1!==b.indexOf(h)){var k=g.shift();k&&(k=k.split("-"),c.push({id:g.join("."),Hb:1*k[0]||1,ib:1*k[1]||1}))}}return c}
var Sf=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,Tf=/(^|\.)doubleclick\.net$/i,Pf=function(a,b){return Tf.test(document.location.hostname)||"/"===b&&Sf.test(a)},Of=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));var e=document.location.hostname;Tf.test(e)||Sf.test(e)||a.push("none");return a};var Uf="".split(/,/),Vf=!1;var Wf=null,Xf={},Yf={},Zf;function $f(a,b){var c={event:a};b&&(c.eventModel=C(b),b[H.fc]&&(c.eventCallback=b[H.fc]),b[H.Pa]&&(c.eventTimeout=b[H.Pa]));return c}
var fg={config:function(a){},
event:function(a){var b=a[1];if(f(b)&&!(3<a.length)){var c;if(2<a.length){if(!Pa(a[2])&&void 0!=a[2])return;c=a[2]}var d=$f(b,c);return d}},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(a){3===a.length&&(void 0).xh().h(a[1],a[2])},set:function(a){var b;2==a.length&&
Pa(a[1])?b=C(a[1]):3==a.length&&f(a[1])&&(b={},Pa(a[2])||ua(a[2])?b[a[1]]=C(a[2]):b[a[1]]=a[2]);if(b){b._clear=!0;return b}}},gg={policy:!0};var hg=function(a,b){var c=a.hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}},jg=function(a){var b=ig(),c=b&&b.hide;c&&c.end&&(c[a]=!0)};
var qg=function(){},lg=function(a,b){var c,d,e,g,h,k,l,m,n,q;return{kb:d,lb:c,Rb:e,Sb:g,Jb:h,Xb:k,fb:l,Ac:m,eb:n,cb:q}},pg=function(a,b){b=void 0===b?"ol":b;},sg=!1,kg,mg,ng,rg,og;var ug=function(a){var b=tg;};var wg=function(a){if(vg(a))return a;this.h=a};wg.prototype.Jf=function(){return this.h};var vg=function(a){return!a||"object"!==Na(a)||Pa(a)?!1:"getUntrustedUpdateValue"in a};wg.prototype.getUntrustedUpdateValue=wg.prototype.Jf;var xg=!1,yg=[];function zg(){if(!xg){xg=!0;for(var a=0;a<yg.length;a++)G(yg[a])}}var Ag=function(a){xg?G(a):yg.push(a)};var Bg=[],Cg=!1,Dg=function(a){return D["dataLayer"].push(a)},Eg=function(a){var b=Oc["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}};
function Fg(a){var b=a._clear;za(a,function(g,h){"_clear"!==g&&(b&&Jd(g,void 0),Jd(g,h))});Tc||(Tc=a["gtm.start"]);a:{}var c=a.event;if(!c)return!1;var d=a["gtm.uniqueEventId"];d||(d=Zc(),a["gtm.uniqueEventId"]=d,Jd("gtm.uniqueEventId",d));Vc=c;var e=Gg(a);Vc=
null;switch(c){case "gtm.init":I("GTM",19),e&&I("GTM",20)}return e}function Gg(a){var b=a.event,c=a["gtm.uniqueEventId"],d,e=Oc.zones;d=e?e.checkState(Nc.s,c):ie;return d.active?ff(c,b,d.isWhitelisted,a.eventCallback,a.eventTimeout)?!0:!1:!1}
function Hg(){for(var a=!1;!Cg&&0<Bg.length;){Cg=!0;delete Ad.eventModel;Cd();var b=Bg.shift();if(null!=b){var c=vg(b);if(c){var d=b;b=vg(d)?d.getUntrustedUpdateValue():void 0;for(var e=["gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],g=0;g<e.length;g++){var h=e[g],k=Dd(h,1);if(ua(k)||Pa(k))k=C(k);Bd[h]=k}}try{if(qa(b))try{b.call(Ed)}catch(v){}else if(ua(b)){var l=b;if(f(l[0])){var m=
l[0].split("."),n=m.pop(),q=l.slice(1),u=Dd(m.join("."),2);if(void 0!==u&&null!==u)try{u[n].apply(u,q)}catch(v){}}}else{var p=b;if(p&&("[object Arguments]"==Object.prototype.toString.call(p)||Object.prototype.hasOwnProperty.call(p,"callee"))){a:{if(b.length&&f(b[0])){var t=fg[b[0]];if(t&&(!c||!gg[b[0]])){b=t(b);break a}}b=void 0}if(!b){Cg=!1;continue}}a=Fg(b)||a}}finally{c&&Cd(!0)}}Cg=!1}
return!a}function Ig(){var a=Hg();try{hg(D["dataLayer"],Nc.s)}catch(b){}return a}
var Kg=function(){var a=ac("dataLayer",[]),b=ac("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};qe(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});Ag(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||0)+1;var c=a.push;a.push=function(){var d;if(0<Oc.SANDBOXED_JS_SEMAPHORE){d=[];for(var e=0;e<arguments.length;e++)d[e]=new wg(arguments[e])}else d=[].slice.call(arguments,0);var g=c.apply(a,d);Bg.push.apply(Bg,d);if(300<
this.length)for(I("GTM",4);300<this.length;)this.shift();var h="boolean"!==typeof g||g;return Hg()&&h};Bg.push.apply(Bg,a.slice(0));Jg()&&G(Ig)},Jg=function(){var a=!0;return a};var Lg={};Lg.pb=new String("undefined");
var Mg=function(a){this.h=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===Lg.pb?b:a[d]);return c.join("")}};Mg.prototype.toString=function(){return this.h("undefined")};Mg.prototype.valueOf=Mg.prototype.toString;Lg.Me=Mg;Lg.nc={};Lg.tf=function(a){return new Mg(a)};var Ng={};Lg.Kg=function(a,b){var c=Zc();Ng[c]=[a,b];return c};Lg.Wd=function(a){var b=a?0:1;return function(c){var d=Ng[c];if(d&&"function"===typeof d[b])d[b]();Ng[c]=void 0}};Lg.ag=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=
b||8===a[d],c=c||16===a[d];return b&&c};Lg.Ag=function(a){if(a===Lg.pb)return a;var b=Zc();Lg.nc[b]=a;return'google_tag_manager["'+Nc.s+'"].macro('+b+")"};Lg.ng=function(a,b,c){a instanceof Lg.Me&&(a=a.h(Lg.Kg(b,c)),b=pa);return{Bc:a,B:b}};var Og=function(a,b,c){function d(g,h){var k=g[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||ic(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},Pg=function(a){Oc.hasOwnProperty("autoEventsSettings")||(Oc.autoEventsSettings={});var b=Oc.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},Qg=function(a,b,c){Pg(a)[b]=c},Rg=function(a,b,c,d){var e=Pg(a),g=Ga(e,b,d);e[b]=c(g)},Sg=function(a,b,c){var d=Pg(a);return Ga(d,b,c)};var Tg=function(){for(var a=Zb.userAgent+(F.cookie||"")+(F.referrer||""),b=a.length,c=D.history.length;0<c;)a+=c--^b++;var d=1,e,g,h;if(a)for(d=0,g=a.length-1;0<=g;g--)h=a.charCodeAt(g),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(Fa()/1E3)].join(".")},Wg=function(a,b,c,d){var e=Ug(b);return Mf(a,e,Vg(c),d)},Xg=function(a,b,c,d){var e=""+Ug(c),g=Vg(d);1<g&&(e+="-"+g);return[b,e,a].join(".")},Ug=function(a){if(!a)return 1;
a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},Vg=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};var Yg=["1"],Zg={},ch=function(a,b,c,d){var e=$g(a);Zg[e]||ah(e,b,c)||(bh(e,Tg(),b,c,d),ah(e,b,c))};function bh(a,b,c,d,e){var g=Xg(b,"1",d,c);Rf(a,g,c,d,0==e?void 0:new Date(Fa()+1E3*(void 0==e?7776E3:e)))}function ah(a,b,c){var d=Wg(a,b,c,Yg);d&&(Zg[a]=d);return d}function $g(a){return(a||"_gcl")+"_au"};var dh=function(){for(var a=[],b=F.cookie.split(";"),c=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,d=0;d<b.length;d++){var e=b[d].match(c);e&&a.push({$c:e[1],value:e[2]})}var g={};if(!a||!a.length)return g;for(var h=0;h<a.length;h++){var k=a[h].value.split(".");"1"==k[0]&&3==k.length&&k[1]&&(g[a[h].$c]||(g[a[h].$c]=[]),g[a[h].$c].push({timestamp:k[1],Gf:k[2]}))}return g};function eh(){for(var a=fh,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function gh(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var fh,hh;function ih(a){fh=fh||gh();hh=hh||eh();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,g=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=g>>2,m=(g&3)<<4|h>>4,n=(h&15)<<2|k>>6,q=k&63;e||(q=64,d||(n=64));b.push(fh[l],fh[m],fh[n],fh[q])}return b.join("")}
function jh(a){function b(l){for(;d<a.length;){var m=a.charAt(d++),n=hh[m];if(null!=n)return n;if(!/^[\s\xa0]*$/.test(m))throw Error("Unknown base64 encoding at char: "+m);}return l}fh=fh||gh();hh=hh||eh();for(var c="",d=0;;){var e=b(-1),g=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|g>>4);64!=h&&(c+=String.fromCharCode(g<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var kh;function lh(a,b){if(!a||b===F.location.hostname)return!1;for(var c=0;c<a.length;c++)if(a[c]instanceof RegExp){if(a[c].test(b))return!0}else if(0<=b.indexOf(a[c]))return!0;return!1}
var ph=function(){var a=mh,b=nh,c=oh(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){gc(F,"mousedown",d);gc(F,"keyup",d);gc(F,"submit",e);var g=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);g.call(this)};c.init=!0}},oh=function(){var a=ac("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var qh=/(.*?)\*(.*?)\*(.*)/,rh=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,sh=/^(?:www\.|m\.|amp\.)+/,th=/([^?#]+)(\?[^#]*)?(#.*)?/,uh=/(.*?)(^|&)_gl=([^&]*)&?(.*)/,wh=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(ih(String(d))))}var e=b.join("*");return["1",vh(e),e].join("*")},vh=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||
window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=kh)){for(var e=Array(256),g=0;256>g;g++){for(var h=g,k=0;8>k;k++)h=h&1?h>>>1^3988292384:h>>>1;e[g]=h}d=e}kh=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^kh[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},yh=function(){return function(a){var b=Re(D.location.href),c=b.search.replace("?",""),d=Ne(c,"_gl",!0)||"";a.query=xh(d)||{};var e=Qe(b,"fragment").match(uh);a.fragment=xh(e&&e[3]||
"")||{}}},zh=function(){var a=yh(),b=oh();b.data||(b.data={query:{},fragment:{}},a(b.data));var c={},d=b.data;d&&(Ia(c,d.query),Ia(c,d.fragment));return c},xh=function(a){var b;b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var g=qh.exec(d);if(g){c=g;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var m=h[2],n=0;n<b;++n)if(m===vh(k,n)){l=!0;break a}l=!1}if(l){for(var q={},u=k?k.split("*"):[],p=0;p<u.length;p+=2)q[u[p]]=jh(u[p+1]);return q}}}}catch(t){}};
function Ah(a,b,c){function d(m){var n=m,q=uh.exec(n),u=n;if(q){var p=q[2],t=q[4];u=q[1];t&&(u=u+p+t)}m=u;var v=m.charAt(m.length-1);m&&"&"!==v&&(m+="&");return m+l}c=void 0===c?!1:c;var e=th.exec(b);if(!e)return"";var g=e[1],h=e[2]||"",k=e[3]||"",l="_gl="+a;c?k="#"+d(k.substring(1)):h="?"+d(h.substring(1));return""+g+h+k}
function Bh(a,b,c){for(var d={},e={},g=oh().decorators,h=0;h<g.length;++h){var k=g[h];(!c||k.forms)&&lh(k.domains,b)&&(k.fragment?Ia(e,k.callback()):Ia(d,k.callback()))}if(Ja(d)){var l=wh(d);if(c){if(a&&a.action){var m=(a.method||"").toLowerCase();if("get"===m){for(var n=a.childNodes||[],q=!1,u=0;u<n.length;u++){var p=n[u];if("_gl"===p.name){p.setAttribute("value",l);q=!0;break}}if(!q){var t=F.createElement("input");t.setAttribute("type","hidden");t.setAttribute("name","_gl");t.setAttribute("value",
l);a.appendChild(t)}}else if("post"===m){var v=Ah(l,a.action);Le.test(v)&&(a.action=v)}}}else Ch(l,a,!1)}if(!c&&Ja(e)){var w=wh(e);Ch(w,a,!0)}}function Ch(a,b,c){if(b.href){var d=Ah(a,b.href,void 0===c?!1:c);Le.test(d)&&(b.href=d)}}
var mh=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var g=e.protocol;"http:"!==g&&"https:"!==g||Bh(e,e.hostname,!1)}}catch(h){}},nh=function(a){try{if(a.action){var b=Qe(Re(a.action),"host");Bh(a,b,!0)}}catch(c){}},Dh=function(a,b,c,d){ph();var e={callback:a,domains:b,fragment:"fragment"===c,forms:!!d};oh().decorators.push(e)},Eh=function(){var a=F.location.hostname,b=rh.exec(F.referrer);if(!b)return!1;
var c=b[2],d=b[1],e="";if(c){var g=c.split("/"),h=g[1];e="s"===h?decodeURIComponent(g[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var k=a.replace(sh,""),l=e.replace(sh,""),m;if(!(m=k===l)){var n="."+l;m=k.substring(k.length-n.length,k.length)===n}return m},Fh=function(a,b){return!1===a?!1:a||b||Eh()};var Gh={};var Hh=/^\w+$/,Ih=/^[\w-]+$/,Jh=/^~?[\w-]+$/,Kh={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp"};function Lh(a){return a&&"string"==typeof a&&a.match(Hh)?a:"_gcl"}var Nh=function(){var a=Re(D.location.href),b=Qe(a,"query",!1,void 0,"gclid"),c=Qe(a,"query",!1,void 0,"gclsrc"),d=Qe(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||Ne(e,"gclid",void 0);c=c||Ne(e,"gclsrc",void 0)}return Mh(b,c,d)};
function Mh(a,b,c){var d={},e=function(g,h){d[h]||(d[h]=[]);d[h].push(g)};if(void 0!==a&&a.match(Ih))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":(void 0==Gh.gtm_3pds?0:Gh.gtm_3pds)&&e(a,"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha");break;case "gp":e(a,"gp")}c&&e(c,"dc");return d}var Ph=function(a){var b=Nh();Oh(b,a)};
function Oh(a,b,c){function d(q,u){var p=Qh(q,e);p&&Rf(p,u,h,g,l,!0)}b=b||{};var e=Lh(b.prefix),g=b.domain||"auto",h=b.path||"/",k=void 0==b.Ja?7776E3:b.Ja;c=c||Fa();var l=0==k?void 0:new Date(c+1E3*k),m=Math.round(c/1E3),n=function(q){return["GCL",m,q].join(".")};a.aw&&(!0===b.Ih?d("aw",n("~"+a.aw[0])):d("aw",n(a.aw[0])));a.dc&&d("dc",n(a.dc[0]));a.gf&&d("gf",n(a.gf[0]));a.ha&&d("ha",n(a.ha[0]));a.gp&&d("gp",n(a.gp[0]))}
var Sh=function(a,b,c,d,e){for(var g=zh(),h=Lh(b),k=0;k<a.length;++k){var l=a[k];if(void 0!==Kh[l]){var m=Qh(l,h),n=g[m];if(n){var q=Math.min(Rh(n),Fa()),u;b:{for(var p=q,t=Jf(m,F.cookie),v=0;v<t.length;++v)if(Rh(t[v])>p){u=!0;break b}u=!1}u||Rf(m,n,c,d,0==e?void 0:new Date(q+1E3*(null==e?7776E3:e)),!0)}}}var w={prefix:b,path:c,domain:d};Oh(Mh(g.gclid,g.gclsrc),w)},Qh=function(a,b){var c=Kh[a];if(void 0!==c)return b+c},Rh=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||
0)};function Th(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var Uh=function(a,b,c,d,e){if(ua(b)){var g=Lh(e);Dh(function(){for(var h={},k=0;k<a.length;++k){var l=Qh(a[k],g);if(l){var m=Jf(l,F.cookie);m.length&&(h[l]=m.sort()[m.length-1])}}return h},b,c,d)}},Vh=function(a){return a.filter(function(b){return Jh.test(b)})},Wh=function(a,b){for(var c=Lh(b&&b.prefix),d={},e=0;e<a.length;e++)Kh[a[e]]&&(d[a[e]]=Kh[a[e]]);za(d,function(g,h){var k=Jf(c+h,F.cookie);if(k.length){var l=k[0],m=Rh(l),n={};n[g]=[Th(l)];Oh(n,b,m)}})};var Xh=/^\d+\.fls\.doubleclick\.net$/;function Yh(a){var b=Re(D.location.href),c=Qe(b,"host",!1);if(c&&c.match(Xh)){var d=Qe(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function Zh(a,b){if("aw"==a||"dc"==a){var c=Yh("gcl"+a);if(c)return c.split(".")}var d=Lh(b);if("_gcl"==d){var e;e=Nh()[a]||[];if(0<e.length)return e}var g=Qh(a,d),h;if(g){var k=[];if(F.cookie){var l=Jf(g,F.cookie);if(l&&0!=l.length){for(var m=0;m<l.length;m++){var n=Th(l[m]);n&&-1===r(k,n)&&k.push(n)}h=Vh(k)}else h=k}else h=k}else h=[];return h}
var $h=function(){var a=Yh("gac");if(a)return decodeURIComponent(a);var b=dh(),c=[];za(b,function(d,e){for(var g=[],h=0;h<e.length;h++)g.push(e[h].Gf);g=Vh(g);g.length&&c.push(d+":"+g.join(","))});return c.join(";")},ai=function(a,b,c,d,e){ch(b,c,d,e);var g=Zg[$g(b)],h=Nh().dc||[],k=!1;if(g&&0<h.length){var l=Oc.joined_au=Oc.joined_au||{},m=b||"_gcl";if(!l[m])for(var n=0;n<h.length;n++){var q="https://adservice.google.com/ddm/regclk",u=q=q+"?gclid="+h[n]+"&auiddc="+g;Zb.sendBeacon&&Zb.sendBeacon(u)||fc(u);k=l[m]=
!0}}null==a&&(a=k);if(a&&g){var p=$g(b),t=Zg[p];t&&bh(p,t,c,d,e)}};var bi;if(3===Nc.tb.length)bi="g";else{var ci="G";bi=ci}
var di={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:bi,OPT:"o"},ei=function(a){var b=Nc.s.split("-"),c=b[0].toUpperCase(),d=di[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",g;if(3===Nc.tb.length){var h=void 0;h=h||"z";g="2"+(h||"w")}else g=
"";return g+d+Nc.tb+e};var ji=["input","select","textarea"],ki=["button","hidden","image","reset","submit"],li=function(a){var b=a.tagName.toLowerCase();return!va(ji,function(c){return c===b})||"input"===b&&va(ki,function(c){return c===a.type.toLowerCase()})?!1:!0},mi=function(a){return a.form?a.form.tagName?a.form:F.getElementById(a.form):lc(a,["form"],100)},ni=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,g=1;e<a.elements.length;e++){var h=a.elements[e];if(li(h)){if(h.getAttribute(c)===d)return g;
g++}}return 0};var qi=!!D.MutationObserver,ri=void 0,si=function(a){if(!ri){var b=function(){var c=F.body;if(c)if(qi)(new MutationObserver(function(){for(var e=0;e<ri.length;e++)G(ri[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;gc(c,"DOMNodeInserted",function(){d||(d=!0,G(function(){d=!1;for(var e=0;e<ri.length;e++)G(ri[e])}))})}};ri=[];F.body?b():G(b)}ri.push(a)};var Oi=D.clearTimeout,Pi=D.setTimeout,R=function(a,b,c){if(Md()){b&&G(b)}else return cc(a,b,c)},Qi=function(){return D.location.href},Ri=function(a){return Qe(Re(a),"fragment")},Si=function(a){return Pe(Re(a))},W=function(a,b){return Dd(a,b||2)},Ti=function(a,b,c){var d;b?(a.eventCallback=b,c&&(a.eventTimeout=c),d=Dg(a)):d=Dg(a);return d},Ui=function(a,b){D[a]=b},X=function(a,b,c){b&&(void 0===D[a]||c&&!D[a])&&(D[a]=
b);return D[a]},Vi=function(a,b,c){return Jf(a,b,void 0===c?!0:!!c)},Wi=function(a,b){if(Md()){b&&G(b)}else ec(a,b)},Xi=function(a){return!!Sg(a,"init",!1)},Yi=function(a){Qg(a,"init",!0)},Zi=function(a,b){var c=(void 0===b?0:b)?"www.google-analytics.com/gtag/js":Sc;c+="?id="+encodeURIComponent(a)+"&l=dataLayer";R(Q("https://","http://",c))},$i=function(a,b){var c=a[b];return c};
var aj=Lg.ng;var bj;
var cj=function(a){if(!a||a.nodeType!=Node.ELEMENT_NODE)return!1;var b=a.tagName.toUpperCase();return"SCRIPT"==b||"STYLE"==b||"LINK"==b},dj=function(a,b,c){null==c?a.removeAttribute(b):a.setAttribute(b,c)},ej=function(a,b,c){var d=a.getAttribute(b);dj(a,b,c);return function(){dj(a,b,d)}},hj=function(a,b,c){var d,e,g=a.ownerDocument||a.document||document;c=(c||"").toLowerCase();"after"==c?(d=a.parentNode,e=a.nextSibling):"insert"==c?(d=a,e=a.firstChild):"append"==c?(d=a,e=null):(d=a.parentNode,e=a);
if(!d||d==g)return{result:1,Zf:[]};var h=fj(b,d);gj(h,"SCRIPT");gj(h,"NOSCRIPT");var k=[];if(h.firstChild)for(var l=h.firstChild;l;){var m=l.nextSibling;k.push(l);d.insertBefore(l,e);l=m}var n=a.nextSibling;"replace"==c&&d.removeChild(a);return{result:function(){for(;0<k.length;)d.removeChild(k.pop());"replace"==c&&d.insertBefore(a,n)},Zf:k.slice()}},ij={SELECT:[1,'<select multiple="multiple">',"</select>"],FIELDSET:[1,"<fieldset>","</fieldset>"],MAP:[1,"<map>","</map>"],OBJECT:[1,"<object>","</object>"],
TABLE:[1,"<table>","</table>"],TBODY:[2,"<table><tbody>","</tbody></table>"],COLGROUP:[2,"<table><colgroup>","</colgroup></table>"],TR:[3,"<table><tbody><tr>","</tr></tbody></table>"]},fj=function(a,b){var c=0,d="",e="",g=ij[b.tagName];null!=g&&(c=g[0],d=g[1],e=g[2]);var h=document.createElement("div");h.innerHTML=d+(a||"")+e;for(var k=h;0<c;){var l=k.firstChild;if(!(l instanceof Element))return document.createElement("div");k=l;c--}return k},gj=function(a,b){for(var c=a.getElementsByTagName(b),d=
[],e=c.length-1;0<=e;e--){var g=c[e];g.parentNode.removeChild(g);d.push(g)}},jj=function(a){var b=null,c=null;try{b=new Function("element",a)}catch(d){c=d}return{yc:b,error:c}},nj=function(a,b,c,d,e){var g=a+"{"+(b+": "+c+(d?" !important":""))+"}";e&&(g=e+"{"+g+"}");var h=document;if(h.createStyleSheet){var k=kj(h),l=k.rules.length;k.insertRule(g,l);return function(){k.deleteRule?k.deleteRule(l):k.removeRule(l);k.insertRule("x {}",l)}}var m=lj(g,h);mj(m,h);var n=m.parentNode;return function(){n.removeChild(m)}},
oj=null,kj=function(a){if(oj)return oj;for(var b=a.styleSheets.length-1;0<=b;b--){var c=a.styleSheets[b],d=c.ownerNode;if(d&&d.parentNode&&"HEAD"==d.parentNode.tagName)return oj=c}0==a.styleSheets.length&&a.createStyleSheet();return bj=a.styleSheets[0]},lj=function(a,b){var c=(b||document).createElement("style");void 0!==c.cssText?c.cssText=a:c.innerHTML=a;return c},mj=function(a,b){var c=b||document,d=c.getElementsByTagName("head")[0];d||(d=c.createElement("head"),c.body.parentNode.insertBefore(d,
c.body));d.appendChild(a)},pj=function(a,b,c,d){if(a.style.setProperty)try{var e=a.style.getPropertyValue(b),g=a.style.getPropertyPriority(b);a.style.setProperty(b,c,d?"important":"");return function(){a.style.setProperty(b,"",g);a.style.setProperty(b,e,g)}}catch(k){}var h=a.style.cssText;a.style.cssText+=";"+(b+": "+c+(d?" !important":""))+";";return function(){a.style.cssText=h}},rj=function(a,b,c,d){if(cj(a))return 7;if(b)return qj(a,b,d);if(c&&c.parentNode){var e=a.parentNode,g=a.nextSibling;
c.parentNode.insertBefore(a,c.nextSibling);return function(){e.insertBefore(a,g)}}return 4},qj=function(a,b,c){var d=a.parentNode,e=a.nextSibling;c=(c||"").toLowerCase();if("bottom"==c)b.appendChild(a);else if("top"==c)b.insertBefore(a,b.childNodes[0]||null);else if("before"==c)if(b.parentNode)b.parentNode.insertBefore(a,b);else return 5;else if("after"==c)if(b.parentNode)b.parentNode.insertBefore(a,b.nextSibling);else return 5;return function(){d.insertBefore(a,e)}},sj=function(a,b,c){if(0<=b&&b<
a.childNodes.length){var d=a.childNodes[b];if(null!=d&&d.nodeType==Node.TEXT_NODE){var e=d.nodeValue;d.nodeValue=c;return function(){d.nodeValue=e}}return 2}return 3},tj=function(a,b,c,d){c?d=c.nextSibling:d&&(c=d.previousSibling);if(null!=c&&c.nodeType==Node.TEXT_NODE){var e=c.nodeValue;c.nodeValue+=a;return function(){c.nodeValue=e}}if(null!=d&&d.nodeType==Node.TEXT_NODE){var g=d.nodeValue;d.nodeValue=a+d.nodeValue;return function(){d.nodeValue=g}}var h=(b.ownerDocument||b.document||document).createTextNode(a);
d?b.insertBefore(h,d):b.appendChild(h);return function(){b.removeChild(h)}},uj=function(a){var b=document.createElement("a");a&&(b.href=a);return b};var yj=new xa;function zj(a,b){function c(h){var k=Re(h),l=Qe(k,"protocol"),m=Qe(k,"host",!0),n=Qe(k,"port"),q=Qe(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==n||"https"==l&&"443"==n)l="web",n="default";return[l,m,n,q]}for(var d=c(String(a)),e=c(String(b)),g=0;g<d.length;g++)if(d[g]!==e[g])return!1;return!0}
function Aj(a){return Bj(a)?1:0}
function Bj(a){var b=a.arg0,c=a.arg1;if(a.any_of&&ua(c)){for(var d=0;d<c.length;d++)if(Aj({"function":a["function"],arg0:b,arg1:c[d]}))return!0;return!1}switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var e;a:{if(b){var g=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var h=0;h<g.length;h++)if(b[g[h]]){e=b[g[h]](c);break a}}catch(v){}}e=!1}return e;case "_ew":var k,l;k=String(b);l=String(c);var m=k.length-
l.length;return 0<=m&&k.indexOf(l,m)==m;case "_eq":return String(b)==String(c);case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var n;n=String(b).split(",");return 0<=r(n,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var q;var u=a.ignore_case?"i":void 0;try{var p=String(c)+u,t=yj.get(p);t||(t=new RegExp(c,u),yj.set(p,t));q=t.test(b)}catch(v){q=!1}return q;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return zj(b,
c)}return!1};var Cj=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var Dj={},Ej=encodeURI,Y=encodeURIComponent,Fj=fc;var Gj=function(a,b){if(!a)return!1;var c=Qe(Re(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var g=c.length-e.length;0<g&&"."!=e.charAt(0)&&(g--,e="."+e);if(0<=g&&c.indexOf(e,g)==g)return!0}}return!1};
var Hj=function(a,b,c){for(var d={},e=!1,g=0;a&&g<a.length;g++)a[g]&&a[g].hasOwnProperty(b)&&a[g].hasOwnProperty(c)&&(d[a[g][b]]=a[g][c],e=!0);return e?d:null};Dj.bg=function(){var a=!1;return a};var Kj=function(a){if(!Ij[a]){Ij[a]=!0;var b=D[a]||{};D[a]=b;var c=function(e){return Jj[e]},d=b.get;b.get=d?function(e){return void 0!==Jj[e]?Jj[e]:d(e)}:c}},Lj=function(a,b,c){try{a(c,b)}catch(d){}},Nj=function(a){Mj[a]=Mj[a]||[];return Mj[a]},Jj={},Mj={},Ij={};
var Oj=function(a){D.gaData=D.gaData||{};var b=D.gaData,c=b.tracker_created;b.tracker_created=function(d){c&&qa(c)&&c(d);a(d)}},Pj=function(a){var b=D[Ie()];try{if(qa(b)&&qa(b.getAll))return va(b.getAll(),function(c){return c.get("trackingId")===a})}catch(c){console.log("Optimize: GA Exception "+c+" trackingId: "+a+" exception: "+c)}},Vj=function(a,b){var c=Qj[a];if(c)G(function(){return b(c)});else{var d=Pj(a);d?(Qj[a]=d,Rj||(Rj=d),G(function(){return b(d)})):(Sj[a]||(Sj[a]=[]),Sj[a].push(b),Tj||
(Tj=!0,Oj(function(e){var g=e.get("trackingId");if(Sj[g]){if(Uj[g]){Uj[g]=!1;var h=D[Ie()];qa(h)&&h("ga.require",Nc.s)}Rj||(Rj=e);Qj[g]=e;for(var k=Sj[g],l;void 0!==(l=k.shift());)l(e);Sj[g]=void 0}})))}},Qj={},Sj={},Uj={},Rj,Tj=!1,Wj=function(a,b){Vj(a,function(c){var d=D[Ie()];try{var e="t0"!=c.get("name")?c.get("name")+".send":"send";d(e,b)}catch(g){console.log("Optimize: failed to send hit using tracker: "+c.name+" exception "+g)}})};

var ak=function(a,b,c){function d(){g||(g=!0,!0!==Xj&&(Xj=!1),Yj(c),hg(ig(),e))}tg=a;var e="GTM-PQN88B9_"+b,g=!1;jg(e);D.google_optimize=D.google_optimize||{};var h=D.google_optimize;h["GTM-PQN88B9"]=h["GTM-PQN88B9"]||{};h["GTM-PQN88B9"].optimize_dyn=function(l){l.split(",").forEach(function(m){Zj[m]=!0});Xj=!0;d()};cc(a,void 0,d);var k=ig();D.setTimeout(function(){d()},Number(k&&k.hide&&k.hide.timeout)||1E4)},Yj=function(a){if(void 0!==bk){var b=bk-ck,c,d;Xj?c=Fa()-bk:d=Fa()-bk;ug({Vg:b,ig:c,gg:d})}Zj.optimize_ready=
!0;Dg({event:"opt.dyn"});Dg({event:"opt.js"});if(a&&0<a.length){var e={};ig().forEach(function(g){var h=g.event;h&&(e[h]=!0)});a.forEach(function(g){e[g]&&Dg({event:g})})}G(function(){Je()})},ig=function(){return D["dataLayer"]},dk=function(a,b,c,d,e,g,h){function k(p,t){t&&(q+="&"+p+"="+encodeURIComponent(t))}ck=Fa();if(a||b||c){var l=void 0;if(b){var m=Nh().aw;m&&(l=m[0])}if(g&&(a||c||l)){var n=1,q,u="GTM-PQN88B9_"+n++;jg(u);Uj[d]=!0;Vj(d,function(p){bk=Fa();a||b?(q="?id=GTM-PQN88B9",
a&&k("cid",p.get("clientId")),k("gclid",l),h&&(k("gtm_auth",""),k("gtm_preview",""),k("cb",String(Math.random()))),ak(q,n++,e)):Yj(e);hg(ig(),u)})}else Yj(e)}},Zj={},ck,bk,Xj,tg;var ek=function(a,b){this.Hb=a;this.ib=b};ek.prototype.toString=function(){var a=""+this.Hb;1<this.ib&&(a=a+"-"+this.ib);return a};var fk=function(a,b){this.i=a;this.h=b};fk.prototype.toString=function(){return this.h+"."+this.i};
var gk=function(){var a=Dd("optimize.cookie_path",2);return f(a)?a:"/"},ik=function(a,b){var c=new hk(a,b);c.wg();return c},hk=function(a,b){this.P=Math.floor(new Date/864E5);this.i=a||"auto";this.h=b||gk();this.o=new ek(Ug(this.i),Vg(this.h));this.m=[];this.map={}};aa=hk.prototype;aa.If=function(a){if(!a)return"";var b=this.be(a);return b?b.i:""};aa.Ng=function(a,b,c,d,e){var g,h;g=void 0===g?10:g;h=void 0===h?3E3:h;if(!a)return!1;void 0==b&&(b="");this.Vb(a,new fk(b,c));this.Xe(e);return this.pg(d,
g,h)};aa.be=function(a){return this.map[a]};aa.Vb=function(a,b){a&&(""==b.i?this.me(a):(this.map[a]||this.m.push(a),this.map[a]=b))};aa.Qg=function(a){for(var b=0;b<a.length;b++)this.Vb(a[b][0],a[b][1])};aa.me=function(a){var b=r(this.m,a);0<=b&&this.m.splice(b,1);delete this.map[a]};aa.Fg=function(){for(var a=[],b=0;b<this.m.length;b++){var c=this.m[b];this.map[c].h<this.P&&a.push(c)}for(var d=0;d<a.length;d++)this.me(a[d])};aa.Hf=function(){for(var a=[],b=0;b<this.m.length;b++){var c=this.m[b];
a.push([c,this.map[c]])}return a};aa.yf=function(){for(var a=0,b=0;b<this.m.length;b++)a=Math.max(a,this.map[this.m[b]].h);return 864E5*a};aa.toString=function(){if(0==this.m.length)return"";for(var a=[],b=0;b<this.m.length;b++){var c=this.m[b];a.push(c+"."+this.map[c].toString())}return"GAX1."+this.o.toString()+"."+a.join("!")};aa.pg=function(a,b,c){var d=new Date;this.Fg();if(this.m.length>b||this.m.length>(a||10)&&document.cookie.replace(/(?:;\s*)?(_gaexp=[^;]+)(?:;\s*)?/,this.toString()).length>
c)return!1;d.setTime(this.yf());if("auto"!=this.i)return this.o=new ek(Ug(this.i),Vg(this.h)),Rf("_gaexp",this.toString(),this.h,this.i,d);for(var e=Of(),g=0;g<e.length;g++)if(this.o=new ek(Ug(e[g]),Vg(this.h)),Rf("_gaexp",this.toString(),this.h,e[g],d))return!0;return!1};aa.wg=function(){var a=Mf("_gaexp",this.o.Hb,this.o.ib);if(a){var b=this.xg(a);b&&this.Qg(b.Hf())}};aa.xg=function(a){for(var b=new hk(this.i,this.h),c=a.split("!"),d=0;d<c.length;d++){var e=c[d].split(".");if(3==e.length){if(isNaN(Number(e[1])))return;
b.Vb(e[0],new fk(e[2],Number(e[1])))}}return b};aa.Xe=function(a){a=a||{};var b=0;a.hasOwnProperty("")&&!isNaN(Number(a[""]))&&(b=this.P-Aa(a[""]));for(var c=0;c<this.m.length;c++){var d=this.m[c];if(a.hasOwnProperty(d)&&!isNaN(Number(a[d]))){var e=this.be(d);e.h=Aa(a[d])+b;this.Vb(d,e)}}};
var jk=function(a){if(le)return!0;for(;a;){if(a.nextSibling)return!0;a=a.parentNode}return!1},kk=function(a,b){for(var c=oc(a.H)||[],d=[],e=0;e<c.length;e++){var g=c[e];if(!g.gtmProgressiveApplied||!g.gtmProgressiveApplied[b]){if(a.S&&!jk(g))break;d.push(g)}}return d},lk=function(a,b){return function(){a.gtmProgressiveApplied&&delete a.gtmProgressiveApplied[b]}},mk=function(a,b){a.gtmProgressiveApplied||(a.gtmProgressiveApplied={});a.gtmProgressiveApplied[b]=!0},nk=function(a,b){var c=[];if(b.aa){var d=
kk(b.aa,b.id),e=null;b.Wb&&(e=kk(b.Wb,b.id+"-t"));for(var g=0;g<d.length;g++){var h=d[g],k=void 0;if(null!=e&&(k=e.length>g?e[g]:null,!k&&!le&&(null===b.Wb.F||b.Ud+c.length<b.Wb.F)))break;c.push({element:h,Tg:k})}}if(!le&&b.Re&&(!a||null==b.aa.F||b.aa.F!=b.uc+c.length))return!1;for(var l=0;l<c.length;l++){var m=c[l].element,n=c[l].Tg,q=void 0;b.uc++;mk(m,b.id);n&&(b.Ud++,q=b.id+"-t",mk(n,q));var u=b.Ye(m,n);qa(u)&&b.La.push(u);b.La.push(lk(m,b.id));n&&q&&b.La.push(lk(n,q))}if(b.aa.F&&b.aa.F==b.uc||
le)b.finished=!0;return!0},ok=function(a){for(var b={},c=0;c<a.U.length;c++){var d=a.U[c];if(d.aa){var e=b[d.aa.H];e||(e=b[d.aa.H]=oc(d.aa.H)||[]);for(var g=0;g<e.length;g++){var h=e[g];h.gtmProgressiveApplied&&h.gtmProgressiveApplied[d.id]||(mk(h,d.id),d.La.push(lk(h,d.id)))}}}},pk=function(a){if(!a.Wc){for(var b=a.ab;b<a.U.length;b++){var c=a.U[b],d=b==a.ab;if(!c.finished&&!nk(d,c))break;c.finished&&d&&a.ab++}a.U.length>a.ab?(a.ja||(a.ja=D.setTimeout(function(){a.ja=null;pk(a)},80)),le||a.Nc||(a.Nc=
function(){G(function(){pk(a)})},gc(F,"DOMContentLoaded",a.Nc))):ok(a)}},qk={},rk={},sk=void 0,tk=function(a,b,c,d){var e=sk;if(!nc||!e)return!1;var g={id:e.id+":"+e.U.length,Ye:b,La:[],Re:c,aa:a,uc:0,Wb:d||null,Ud:0,finished:!1};e.U.push(g);null===a?(g.finished=!0,b(null)):pk(e);return!0},uk=function(a){var b=nj(a,"visibility","hidden",!0);return function(){qa(b)&&b.apply();b=null}},vk=function(a,b,c,d){var e=b;if(!le){var g=uk(a.H);ne.push(g);e=function(h,k){var l=b(h,k);g();return l}}return tk(a,
e,c,d)};var Uk=function(){var a=D.gaGlobal=D.gaGlobal||{};a.hid=a.hid||wa();return a.hid};var el=window,fl=document,gl=function(a){var b=el._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===el["ga-disable-"+a])return!0;try{var c=el.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(g){}for(var d=Jf("AMP_TOKEN",fl.cookie,!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return fl.getElementById("__gaOptOutExtension")?!0:!1};var jl=function(a){za(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[H.ba]||{};za(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var nl=function(a,b,c){Cf(b,c,a)},ol=function(a,b,c){Cf(b,c,a,!0)},ql=function(a,b){};
function pl(a,b){}var Z={a:{}};Z.a.dee=["google"],function(){(function(a){Z.__dee=a;Z.__dee.b="dee";Z.__dee.g=!0;Z.__dee.priorityOverride=0})(function(){var a=!1;return a?"gtm.sync":"gtm.js"})}();


Z.a.sel=["google"],function(){(function(a){Z.__sel=a;Z.__sel.b="sel";Z.__sel.g=!0;Z.__sel.priorityOverride=0})(function(a){return oc(a.vtp_selector)})}();

Z.a.c=["google"],function(){(function(a){Z.__c=a;Z.__c.b="c";Z.__c.g=!0;Z.__c.priorityOverride=0})(function(a){return a.vtp_value})}();
Z.a.e=["google"],function(){(function(a){Z.__e=a;Z.__e.b="e";Z.__e.g=!0;Z.__e.priorityOverride=0})(function(a){return String(Ld(a.vtp_gtmEventId,"event"))})}();

Z.a.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){Z.__u=b;Z.__u.b="u";Z.__u.g=!0;Z.__u.priorityOverride=0})(function(b){var c;b.vtp_customUrlSource?c=b.vtp_customUrlSource:c=W("gtm.url",1);c=c||Qi();var d=b[a("vtp_component")];if(!d||"URL"==d)return Si(String(c));var e=Re(String(c)),g;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],m;h?ua(k)?m=k:m=String(k).replace(/\s+/g,
"").split(","):m=[String(k)];for(var n=0;n<m.length;n++){var q=Qe(e,"QUERY",void 0,void 0,m[n]);if(void 0!=q&&(!l||""!==q)){g=q;break a}}g=void 0}else g=Qe(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return g})}();
Z.a.v=["google"],function(){(function(a){Z.__v=a;Z.__v.b="v";Z.__v.g=!0;Z.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=W(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
Z.a.exsu=["google"],function(){(function(a){Z.__exsu=a;Z.__exsu.b="exsu";Z.__exsu.g=!0;Z.__exsu.priorityOverride=0})(function(a){ik(a.vtp_cookieDomain,a.vtp_cookiePath).Ng(a.vtp_measurementId,a.vtp_newState,a.vtp_expirationDay,a.vtp_max,a.vtp_expirationDates)?a.vtp_gtmOnSuccess():a.vtp_gtmOnFailure()})}();
Z.a.ctto=["google"],function(){(function(a){Z.__ctto=a;Z.__ctto.b="ctto";Z.__ctto.g=!0;Z.__ctto.priorityOverride=0})(function(a){var b=a.vtp_isDynamic,c=X("dataLayer"),d=c&&c.hide;if(!d)return!1;var e=Nc.s,g=X("document");if(void 0===g.querySelector)return!1;var h=!!g.querySelector("body");if(null!==d.end||!h)return!1;if(!b)return!0===d[e];for(var k in d)if(d.hasOwnProperty(k)&&k.startsWith(e)&&!0===d[k])return!0;return!1})}();
Z.a.ua=["google"],function(){var a,b={},c=function(d){var e={},g={},h={},k={},l={},m=void 0;if(d.vtp_gaSettings){var n=d.vtp_gaSettings;C(Hj(n.vtp_fieldsToSet,"fieldName","value"),g);C(Hj(n.vtp_contentGroup,"index","group"),h);C(Hj(n.vtp_dimension,"index","dimension"),k);C(Hj(n.vtp_metric,"index","metric"),l);d.vtp_gaSettings=null;n.vtp_fieldsToSet=void 0;n.vtp_contentGroup=void 0;n.vtp_dimension=void 0;n.vtp_metric=void 0;var q=C(n);d=C(d,q)}C(Hj(d.vtp_fieldsToSet,"fieldName","value"),g);C(Hj(d.vtp_contentGroup,
"index","group"),h);C(Hj(d.vtp_dimension,"index","dimension"),k);C(Hj(d.vtp_metric,"index","metric"),l);var u=Ge(d.vtp_functionName);if(qa(u)){var p="",t="";d.vtp_setTrackerName&&"string"==typeof d.vtp_trackerName?""!==d.vtp_trackerName&&(t=d.vtp_trackerName,p=t+"."):(t="gtm"+Zc(),p=t+".");var v={name:!0,clientId:!0,sampleRate:!0,siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,legacyCookieDomain:!0,
legacyHistoryImport:!0,storage:!0,useAmpClientId:!0,storeGac:!0},w={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,allowAdFeatures:!0},y=function(O){var K=[].slice.call(arguments,0);K[0]=p+K[0];u.apply(window,K)},x=function(O,K){return void 0===K?K:O(K)},z=function(O,K){if(K)for(var sa in K)K.hasOwnProperty(sa)&&y("set",O+sa,K[sa])},B=function(){},A=function(O,K,sa){var Eb=0;if(O)for(var Ba in O)if(O.hasOwnProperty(Ba)&&(sa&&v[Ba]||!sa&&void 0===v[Ba])){var Za=w[Ba]?Ca(O[Ba]):O[Ba];"anonymizeIp"!=Ba||Za||(Za=void 0);K[Ba]=Za;Eb++}return Eb},E={name:t};A(g,E,!0);u("create",d.vtp_trackingId||e.trackingId,E);y("set","&gtm",ei(!0));d.vtp_enableRecaptcha&&y("require","recaptcha","recaptcha.js");(function(O,K){void 0!==d[K]&&y("set",O,d[K])})("nonInteraction","vtp_nonInteraction");z("contentGroup",h);z("dimension",k);z("metric",l);var J={};A(g,J,!1)&&y("set",J);var M;M=d.vtp_hitLevelFieldsToSet;
d.vtp_enableLinkId&&y("require","linkid","linkid.js");y("set","hitCallback",function(){var O=g&&g.hitCallback;qa(O)&&O();d.vtp_gtmOnSuccess()});if("TRACK_EVENT"==d.vtp_trackType){}else if("TRACK_SOCIAL"==d.vtp_trackType){}else if("TRACK_TRANSACTION"==d.vtp_trackType){}else if("TRACK_TIMING"==
d.vtp_trackType){}else if("DECORATE_LINK"==d.vtp_trackType){}else if("DECORATE_FORM"==d.vtp_trackType){}else if("TRACK_DATA"==d.vtp_trackType){M?y("send","data",M):y("send","data");}else{d.vtp_enableEcommerce&&(y("require","ec","ec.js"),B());if(d.vtp_doubleClick||"DISPLAY_FEATURES"==d.vtp_advertisingFeaturesType){var oa=
"_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");y("require","displayfeatures",void 0,{cookieName:oa})}if("DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==d.vtp_advertisingFeaturesType){var ja="_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");y("require","adfeatures",{cookieName:ja})}M?y("send","pageview",M):y("send","pageview");}if(!a){var ta=d.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";d.vtp_useInternalVersion&&!d.vtp_useDebugVersion&&(ta="internal/"+ta);a=!0;var ab=Q("https:","http:","//www.google-analytics.com/"+ta,g&&g.forceSSL);R(ab,function(){var O=Ee();O&&O.loaded||d.vtp_gtmOnFailure();},d.vtp_gtmOnFailure)}}else G(d.vtp_gtmOnFailure)};Z.__ua=c;Z.__ua.b="ua";Z.__ua.g=!0;Z.__ua.priorityOverride=0}();
Z.a.dr=["google"],function(){(function(a){Z.__dr=a;Z.__dr.b="dr";Z.__dr.g=!0;Z.__dr.priorityOverride=0})(function(a){var b=a.vtp_treatmentId,c=a.vtp_activate,d=a.vtp_contentSignature,e=a.vtp_isEmpty,g=W("optimize.experimentCallback",1),h=a.vtp_measurementId,k=a.vtp_experimentCombination,l;if(l=c){var m=qk[h];l=!(!m||m==b)}if(l)a.vtp_gtmOnFailure();else{var n=W("optimize.whitelist",1);if(n&&n[h]?n[h]===d:fe()?e:1){if(qa(g)){var q={xid:h,xvar:k,activate:c};try{g(q)}catch(U){}}var u=!1,p=!0;if(c){var t;
qk[h]=b;var v=rk[b];if(v){for(var w=v.ab=0;w<v.U.length;w++)v.U[w].finished=!1;pk(v);t=!0}else t=!1;if(t)u=!0;else{var y=rk[b];y||(y={id:b,U:[],ab:0,ja:null,Nc:void 0,Wc:!1},rk[b]=y);sk=y}}else{var x=rk[b];if(!x||x.Wc)p=!1;else{for(;x.U.length;)for(var z=x.U.pop();z.La.length;){var B=z.La.pop();if(qa(B))try{B()}catch(U){}}x.Wc=!0;delete rk[b];p=!0}}if(p){var A=c?k:void 0;Jj[h]=A;for(var E=Nj(h),J=0;J<E.length;J++)Lj(E[J],h,A);E=Nj("");for(var M=0;M<E.length;M++)Lj(E[M],h,A)}a[u?"vtp_gtmOnFailure":
"vtp_gtmOnSuccess"]()}else a.vtp_gtmOnFailure()}})}();
Z.a.gthc=["google"],function(){(function(a){Z.__gthc=a;Z.__gthc.b="gthc";Z.__gthc.g=!0;Z.__gthc.priorityOverride=0})(function(a){var b=X("gaData",{}),c=!1;if(c)return-1;var d=a.vtp_trackingId;return b[d]&&b[d].hitcount?b[d].hitcount:0})}();
Z.a.uv=["google"],function(){(function(a){Z.__uv=a;Z.__uv.b="uv";Z.__uv.g=!0;Z.__uv.priorityOverride=0})(function(){})}();






Z.a.asprv=["google"],function(){(function(a){Z.__asprv=a;Z.__asprv.b="asprv";Z.__asprv.g=!0;Z.__asprv.priorityOverride=0})(function(a){var b=a.vtp_globalName,c=W("eventModel");b&&Kj(b);var d,e,g;c&&(d=c.name||"",e=c.callback,g=c.remove);if(e&&qa(e))if(d=String(d),!0!==g){var h=d,k=e;Nj(h).push(k);if(""!==h)void 0!==Jj[h]&&Lj(k,h,Jj[h]);else for(var l in Jj)void 0!==Jj[l]&&Lj(k,l,Jj[l])}else{var m=e,n=Nj(d),q=n.indexOf(m);0<=q&&n.splice(q,1)}a.vtp_gtmOnSuccess()})}();
Z.a.gaoo_c=["google"],function(){(function(a){Z.__gaoo_c=a;Z.__gaoo_c.b="gaoo_c";Z.__gaoo_c.g=!0;Z.__gaoo_c.priorityOverride=0})(function(a){var b=X("_gaUserPrefs");try{if(b&&b.ioo&&b.ioo())return!0}catch(d){}if(F.getElementById("__gaOptOutExtension"))return!0;var c=X("external");return c&&"oo"==c._gaUserPrefs?!0:!!X("ga-disable-"+a.vtp_trackingId)})}();

Z.a.noop=["google"],function(){(function(a){Z.__noop=a;Z.__noop.b="noop";Z.__noop.g=!0;Z.__noop.priorityOverride=0})(function(a){a.vtp_gtmOnSuccess()})}();



Z.a.uae=["google"],function(){(function(a){Z.__uae=a;Z.__uae.b="uae";Z.__uae.g=!0;Z.__uae.priorityOverride=0})(function(a){var b=X("gaData",{},!1),c=a.vtp_trackingId,d=a.vtp_measurementId,e=a.vtp_experimentCombination;if(c){b[c]=b[c]||{};var g=b[c];g.pending_experiments=g.pending_experiments||{};g.pending_experiments[d]=e;g.experiments=g.experiments||{};g.experiments[d]=e}var h=!1;if(!c||h)b.expId=d,b.expVar=e;a.vtp_gtmOnSuccess()})}();

Z.a.esc=["customScripts"],function(){(function(a){Z.__esc=a;Z.__esc.b="esc";Z.__esc.g=!0;Z.__esc.priorityOverride=0})(function(a){var b=a.vtp_selector,c=a.vtp_script,d=a.vtp_identifier,e=a.vtp_affectsSelectors,g=a.vtp_requiresContent;!1!==g&&(g=!0);var h=jj(c);h.yc?nc?sk?vk({H:b,S:g,F:b==d?1:null},function(k){if(k&&h.yc){var l;try{var m=(0,h.yc)(k);l="function"==typeof m?m:null}catch(n){l=n}return l}},!!e)?a.vtp_gtmOnSuccess():a.vtp_gtmOnFailure():a.vtp_gtmOnFailure():a.vtp_gtmOnFailure():a.vtp_gtmOnFailure()})}();










var hm={};hm.macro=function(a){if(Lg.nc.hasOwnProperty(a))return Lg.nc[a]},hm.onHtmlSuccess=Lg.Wd(!0),hm.onHtmlFailure=Lg.Wd(!1);hm.dataLayer=Ed;hm.callback=function(a){Xc.hasOwnProperty(a)&&qa(Xc[a])&&Xc[a]();delete Xc[a]};function im(){Oc[Nc.s]=hm;Ia(Yc,Z.a);xb=xb||Lg;yb=he}
function jm(){Gh.gtm_3pds=!0;Oc=D.google_tag_manager=D.google_tag_manager||{};if(Oc[Nc.s]){var a=Oc.zones;a&&a.unregisterChild(Nc.s)}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)pb.push(c[d]);for(var e=b.tags||[],g=0;g<e.length;g++)sb.push(e[g]);for(var h=b.predicates||[],k=0;k<
h.length;k++)rb.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var n=l[m],q={},u=0;u<n.length;u++)q[n[u][0]]=Array.prototype.slice.call(n[u],1);qb.push(q)}vb=Z;wb=Aj;im();Kg();le=!1;me=0;if("interactive"==F.readyState&&!F.createEventObject||"complete"==F.readyState)oe();else{gc(F,"DOMContentLoaded",oe);gc(F,"readystatechange",oe);if(F.createEventObject&&F.documentElement.doScroll){var p=!0;try{p=!D.frameElement}catch(y){}p&&pe()}gc(D,"load",oe)}xg=!1;"complete"===F.readyState?zg():gc(D,
"load",zg);a:{if(!td)break a;D.setInterval(ud,864E5);}
Uc=(new Date).getTime();
}}jm();

})()
